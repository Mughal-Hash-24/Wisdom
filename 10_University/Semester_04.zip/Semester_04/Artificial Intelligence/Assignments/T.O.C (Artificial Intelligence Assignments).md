# Artificial Intelligence Assignments

[[10_University/Semester_04/Artificial Intelligence/T.O.C (Artificial Intelligence).md|Up to Artificial Intelligence]]
