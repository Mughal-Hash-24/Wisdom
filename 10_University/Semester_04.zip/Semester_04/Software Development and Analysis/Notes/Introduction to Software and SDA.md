---
created: 2026-01-20 13:45
tags: [concept, cs, sda]
---
# Introduction to Software and SDA

[[10_University/Semester_04/Software Development and Analysis/Notes/T.O.C (Software Development and Analysis Notes)|Up to SDA Notes]]

## Software
It's a set of instructions that takes inputs perform processing and gives output.

## Gemini
**Simple Terms:**
Think of software as a recipe for a computer. Just as a recipe tells a chef exactly what ingredients to use and what steps to follow to bake a cake, software tells the computer exactly what data to use and what actions to perform to complete a task, like playing a video or sending an email.

**Technical Terms:**
Software is a collection of data and computer instructions that tells the computer how to work. This is in contrast to physical hardware, from which the system is built and actually performs the work. In computer science and software engineering, computer software is all information processed by computer systems, programs and data. Computer software includes computer programs, libraries and related non-executable data, such as online documentation or digital media.

**Examples:**
*   **System Software:** Windows 11, Linux, macOS (manages hardware).
*   **Application Software:** Microsoft Word (word processing), Chrome (web browsing), Spotify (music streaming).
*   **Programming Software:** VS Code, IntelliJ IDEA (tools to write other software).

## SDA
SDA stands for Software development analysis.

## Gemini
**Breakdown:**
1.  **Software:** The set of programs, instructions, and data that control the computer (as defined above). It is the "what" we are building.
2.  **Development:** The systematic process of creating the software. This involves coding, testing, debugging, and maintaining the application. It is the "how" we build it.
3.  **Analysis:** The critical investigation of the problem domain. It involves breaking down a complex system to understand its requirements, constraints, and underlying logic *before* and *during* development. It is the "why" and "what for" - ensuring we build the *right* thing.

**Example: Building a Library Management System**
*   **Software:** The final application used by librarians to check books in and out.
*   **Development:** The actual writing of Java/Python code to create the database connections and user interface.
*   **Analysis:** Interviewing librarians to realize they need a feature to track "overdue fines" specifically for faculty members differently than students. Without this *analysis*, the *development* phase might build a generic fine system that doesn't meet the *software's* real-world needs.

## Java

## Gemini
**What is Java?**
Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible. It is a general-purpose programming language intended to let application developers *write once, run anywhere* (WORA), meaning that compiled Java code can run on all platforms that support Java without the need for recompilation.

**Why for SDA?**
Java is excellent for learning SDA because it enforces strong Object-Oriented Programming (OOP) principles (Encapsulation, Inheritance, Polymorphism) which are central to modern software design and analysis. Its strict type system and extensive standard library allow students to focus on architectural patterns and design structures rather than memory management quirks.

**Better than C++?**
*   **Memory Management:** Java has automatic garbage collection, whereas C++ requires manual memory management. This reduces a whole class of bugs (memory leaks) during the learning of analysis and design concepts.
*   **Simplicity:** Java removes operator overloading and multiple inheritance (using interfaces instead), which simplifies the design model and makes code easier to analyze and maintain.
*   **Platform Independence:** Java runs on the JVM, making it easier to share and deploy artifacts across different student environments compared to C++ binaries.

## Importance of SDA as a course
Every system and software must be well designed and thought out in order to be adhering to standards in terms of quality and safety.

## Gemini
**Importance in a CS Degree:**
SDA is the bridge between "coding" and "engineering." In early CS courses, you learn to write code that *works*. In SDA, you learn to write code that lasts, scales, and is maintainable. It teaches you how to translate vague real-world problems into concrete technical specifications. Without SDA, a developer is just a "coder" who might build a house without a blueprint—it might stand up for a day, but it will collapse under the first storm (scaling/maintenance). It introduces industry-standard methodologies (Agile, Waterfall) that you will use from day one in your career.

**Designing an Artifact in FYP (Final Year Project):**
In a BSCS FYP, "designing an artifact" refers to the creation of the tangible software product or system component that solves your research problem. It is not just the code; it is the *embodiment* of your analysis.
*   **Process:** It involves taking your problem statement, performing requirement analysis, creating design documents (UML diagrams, wireframes), and then implementing (coding) the solution.
*   **Expectation:** The "artifact" must be robust, documented, and testable. It validates your theoretical thesis. For example, if your FYP is about "AI-driven Traffic Control," the artifact is the actual software simulation that controls the traffic lights, which you can demo to the panel.

## Analogy for SDA

## Gemini
**The Architect vs. The Bricklayer**
Imagine building a skyscraper.
*   **Coding (without SDA)** is like laying bricks. You can learn to lay bricks perfectly straight, mix cement well, and stack them high. But if you just start laying bricks without a plan, you might build a wall where a window should be, or forget the space for elevators.
*   **SDA** is the Architecture and Engineering. It's studying the soil (Analysis), drawing the blueprints (Design), and planning the plumbing and electrical systems (Architecture).
*   **Why it's important:** You can build a doghouse (simple script) by just laying bricks. But you cannot build a Burj Khalifa (Enterprise Software) without Architecture (SDA). If you try, it will collapse. SDA ensures the skyscraper stands tall, is safe for people to live in, and doesn't fall over when the wind blows.
