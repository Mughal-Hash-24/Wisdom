# Software Development and Analysis Notes

[[10_University/Semester_04/Software Development and Analysis/T.O.C (Software Development and Analysis)|Up to Software Development and Analysis]]

## Notes Index

| ID      | Category        | Content                   |
| :------ | :-------------- | :------------------------ |
| **1.0** | **Sessional 1** |                           |
| 1.1     |                 | [[Introduction to Software and SDA]] |
| 1.2     |                 | [[SDA Lifecycle and Phases]] |
| 1.3     |                 | [[SDA Methodologies]] |
| 1.4     |                 | [[Software Analysis vs Design]] |
| **2.0** | **Sessional 2** |                           |
| 2.1     |                 |                           |
| **3.0** | **Finals**      |                           |
| 3.1     |                 |                           |
