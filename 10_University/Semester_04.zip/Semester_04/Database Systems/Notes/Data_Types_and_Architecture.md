[[T.O.C (Database Systems Notes)|Up to DB Notes]]

# Types of Data

## Structured Data
**Structured data** refers to information that is highly organized and formatted in a way that makes it easily searchable in relational databases. It adheres to a pre-defined data model, meaning the type of data (e.g., text, number, date) and its relationships are established before any data is created.

*   **Characteristics:** Quantitative, highly organized, fixed schema, easy to analyze.
*   **Storage:** Relational Databases (RDBMS), Spreadsheets.

**Real-World Example:**
Consider a **Bank Transaction Record**. Every transaction has a consistent format:
*   `Transaction_ID` (Integer)
*   `Account_Number` (String)
*   `Date` (DateTime)
*   `Amount` (Decimal)
*   `Merchant` (String)

In a relational database (like a table named `Transactions`), every row represents a single transaction, and every column represents one of these specific attributes. You won't suddenly find a JPEG image in the `Amount` column.

**Role of Oracle and SQL:**
*   **SQL (Structured Query Language):** This is the standard language used to communicate with relational databases. It allows you to define the structure (DDL) and manipulate the data (DML). For example, `SELECT * FROM Transactions WHERE Amount > 1000;`.
*   **Oracle Database:** This is a powerful RDBMS software (a product) that manages structured data. It provides the engine to store the data safely, enforce the schema rules (e.g., "Amount must be a number"), and execute SQL queries efficiently.

## Non-Structured Data
**Unstructured data** (or non-structured data) is information that does not have a pre-defined data model or is not organized in a pre-defined manner. It is typically text-heavy but may contain data such as dates, numbers, and facts as well.

*   **Characteristics:** Qualitative, no fixed schema, difficult to analyze using standard tools, requires massive storage.
*   **Storage:** Data Lakes, NoSQL Databases, Object Storage.

**Real-World Example:**
*   **Social Media Posts (Instagram/LinkedIn):** An Instagram post contains an image (binary data), a caption (text of varying length, emojis, hashtags), comments (nested text), and metadata (location, time). There is no rigid "row and column" structure that fits this perfectly into a standard table without complex transformation.
*   **Emails:** The body of an email is free-text. It might contain a greeting, a paragraph about a meeting, and a signature.

**Systems that Manage Unstructured Data:**
*   **NoSQL Databases:** specifically **Document Stores** (like **MongoDB**) or **Key-Value Stores** (like **Redis**) are designed to handle flexible data structures like JSON documents.
*   **Data Lakes:** (e.g., **Hadoop**, **Amazon S3**) store vast amounts of raw data in its native format until it is needed.

---

# DB Concepts and Architecture

## DB Concepts
*   **DB Schema:** The *description* or *blueprint* of the database. It is specified during the database design and is not expected to change frequently. It defines the tables, the fields in each table, and the relationships between them.
    *   *Example:* Defining that a `Student` has a `Name` (string) and `ID` (number).
*   **DB Schema Diagram:** A visual representation (diagram) of the schema. It shows the tables, columns, and connections (foreign keys) but *not* the actual data.
    *   *Example:* An Entity-Relationship (ER) Diagram.
*   **DB Schema Construct/Object:** The individual components that make up the schema.
    *   *Example:* A single table (`Students`), a specific column (`Student_ID`), or a constraint (`PRIMARY KEY`).

## DB Schema vs DB State

| Feature | DB Schema (Intension) | DB State (Extension/Snapshot) |
| :--- | :--- | :--- |
| **Definition** | The logical design or blueprint of the database. | The actual data stored in the database at a specific moment in time. |
| **Change Frequency** | Infrequent. Changing it is a major event (Database Evolution). | Frequent. Changes every time data is inserted, updated, or deleted. |
| **Visibility** | Defines variables and types. | The values of the variables. |
| **Example 1 (University)** | The rule: "Course table has CourseName and Credits." | The data: "CS101, 4 Credits" exists in the table right now. |
| **Example 2 (Inventory)** | The structure: "Products have Price and Qty." | The snapshot: "Item A has 5 units left" (as of 10:00 AM). |
| **Example 3 (Social)** | The design: "User profile contains bio and photo URL." | The content: "User X's bio is 'Hello world'" (currently). |

---

# Standalones

## Schema Owners and Privileges
In enterprise database environments, not everyone has the same access.
*   **Schema Owner:** The user account that *created* the schema objects. They have full control (ALL PRIVILEGES) over their tables, views, etc. They can alter, drop, or grant access to others.
*   **Editors (Write Access):** Users granted permission to manipulate data (`INSERT`, `UPDATE`, `DELETE`) but usually cannot change the structure (drop tables).
*   **Viewers (Read Access):** Users granted only `SELECT` permission to view data for reporting or analysis.

## DDL Commands
**DDL (Data Definition Language)** commands are used to define or modify the database structure (the schema).

*   **CREATE:** Creates a new object.
    *   `CREATE TABLE Students (ID int, Name varchar(50));`
*   **ALTER:** Modifies an existing object.
    *   `ALTER TABLE Students ADD Email varchar(100);`
*   **DROP:** Deletes an object (and its data!).
    *   `DROP TABLE Students;`
*   **TRUNCATE:** Removes all records from a table (resets state) but keeps the structure.
    *   `TRUNCATE TABLE Students;`

---

# Three Schema Architecture
The **Three-Schema Architecture** (or ANSI/SPARC architecture) is a framework used to separate the user applications from the physical database. This separation supports **Data Independence**.

## 1. External Level (View Level)
*   **What it is:** How individual users perceive the data.
*   **Detail:** Describes only the part of the database relevant to a specific user group.
*   **Example:** A University Student Portal shows the student their grades and schedule. It *hides* faculty salary data, even though that data exists in the same underlying database.
*   **Construct:** `VIEWS`.

## 2. Conceptual Level (Logical Level)
*   **What it is:** The community view of the whole database.
*   **Detail:** Describes *what* data is stored and the relationships. It hides physical storage details. This is the level where the DBA (Database Administrator) works.
*   **Example:** The complete schema: `Students`, `Courses`, `Instructors`, `Grades` tables and their Foreign Key links.

## 3. Internal Level (Physical Level)
*   **What it is:** How the data is physically stored on the hardware.
*   **Detail:** Describes complex low-level data structures, file organizations, index methods (B-trees, Hashing), and compression.
*   **Example:** "The `Students` table is stored in `datafile_01.db` using a B+ Tree index on `Student_ID`."

## Data Independence
*   **Logical Data Independence:** The capacity to change the Conceptual schema without having to change the External schemas (application programs). (e.g., Adding a new field `DateOfBirth` to `Students` shouldn't break the Student Portal).
*   **Physical Data Independence:** The capacity to change the Internal schema without having to change the Conceptual schema. (e.g., Moving data from a hard drive to an SSD or changing an index type shouldn't require rewriting the SQL queries).
