# Introduction to Databases

[[10_University/Semester_04/Database Systems/Notes/T.O.C (Database Systems Notes)|Up to Database Notes]]

## Database Overview
### Introduction
A database is an organized collection of structured information, or data, typically stored electronically in a computer system. It is controlled by a Database Management System (DBMS).

## Gemini: Approaches to Database Introductions
Different schools of thought introduce databases differently:
1.  **The File-System Evolution Approach:** Starts with how we stored data in flat files (txt, csv), highlights the problems (redundancy, inconsistency), and introduces Databases as the solution.
2.  **The Information Systems Approach:** Focuses on the "Data vs Information" distinction. A database is the engine that converts raw facts (Data) into actionable insights (Information).
3.  **The Structural/Relational Approach:** Dives immediately into tables, rows, and columns, defining a database as a collection of related relations.

---

## Data vs. Information
**Data** is raw, unorganized facts that need to be processed. **Information** is data that is processed, organized, structured or presented in a given context so as to make it useful.

## Gemini: The Transformation Process
The journey from Data to Information involves context and processing.
*   **Data:** "38", "John", "A". (Meaningless in isolation).
*   **Processing:** Associating "38" with "Age", "John" with "Name", "A" with "Grade".
*   **Information:** "John is 38 years old and has an 'A' grade."

**DIKW Pyramid:**
1.  **Data:** Raw symbols.
2.  **Information:** Who, what, where, when.
3.  **Knowledge:** How.
4.  **Wisdom:** Why.

---

## DBMS (Database Management System)
## Gemini: Definition & Examples
A **DBMS** is the software that interacts with end-users, applications, and the database itself to capture and analyze the data. It acts as an interface between the user and the physical data.

*   **Analogy:** If the Database is a library of books, the DBMS is the librarian who knows exactly where every book is, how to check them out, and ensures no one steals pages.
*   **Examples:** MySQL, PostgreSQL, Oracle Database, Microsoft SQL Server, MongoDB (NoSQL).

---

## DBMS Functions
The primary functions generally available through a DBMS include:

### 1. Define
## Gemini: The Definition Step
This is the **Schema Definition**. It involves specifying the data types, structures, and constraints of the data to be stored. You are defining the "skeleton" of the database.
*   *Example:* Creating a table `Students` with columns `ID (int)`, `Name (varchar)`, `GPA (float)`.

### 2. Construct
## Gemini: The Construction Step
Construction is the process of **storing the actual data** on the storage medium that is controlled by the DBMS. It distinguishes itself from 'Define' because 'Define' only creates the catalog/metadata, whereas 'Construct' populates the database with instances.
*   *Example:* Inserting the record `{101, "Alice", 3.8}` into the `Students` table.

### 3. Manipulate
## Gemini: The Manipulation Step
This involves querying and updating the database. It includes retrieval (Querying), modification (Updating), insertion (Adding), and deletion (Removing).
*   *Example:* Running `SELECT * FROM Students WHERE GPA > 3.5`.

### 4. Processing
## Gemini: The Processing Step
This refers to the execution of logic on the data. It often ensures ACID properties (Atomicity, Consistency, Isolation, Durability) during transactions. It handles the "business logic" of data access, ensuring that concurrent users don't corrupt data.

### 5. Sharing
## Gemini: The Sharing Step
Sharing allows multiple users and programs to access the database concurrently.
*   **Integration with Processing:** The DBMS uses "Locking" and "Concurrency Control" (part of processing) to ensure that when User A is reading a record, User B doesn't delete it at the exact same millisecond.

---

## Database System
## Gemini: The Organizational Context
A **Database System** refers to the combination of the Database (the data), the DBMS (the software), the Application Programs, and the Users.
*   **"Specified for an Organization":** A DB System isn't generic; it models the specific rules of an entity.
*   **Example (FAST University Portal - Flex):**
    *   **Data:** Student records, marks, attendance.
    *   **DBMS:** Likely Oracle or SQL Server.
    *   **Application:** The web interface you log into.
    *   **Users:** Students, Faculty, Admin.
    *   **The System:** The interaction of all these parts to manage university operations.

## Gemini: Integration Example (Data + Info + DBMS + DB System)
**Scenario: A Supermarket Checkout**
1.  **Data:** Barcode "12345" scanned at checkout.
2.  **DBMS:** The software receives "12345", queries the `Inventory` table (Define/Construct).
3.  **Information:** The DBMS returns "Apple, $0.50". The system calculates Total: $0.50.
4.  **DB System:** The entire rig (Scanner, Cashier Interface, Back-end Server). It subtracts 1 Apple from inventory (Manipulate) and records the sale (Processing).

---

## File Management System (FMS)
Before DBMS, organizations used FMS.
## Gemini: What is FMS?
An **FMS** is essentially using the Operating System's file browser to store data. Each application defines and manages its own data files.
*   *Example:* The HR department has a `employees.txt` file, and the Payroll department has a separate `salaries.csv` file. Both contain employee names.

---

## FMS vs. DBMS
## Gemini: Scenario Comparison

**Scenario:** Updating a Student's Address.

| Step | File Management System (FMS) | Database Management System (DBMS) |
| :--- | :--- | :--- |
| **Input** | User opens `Registration.txt` and updates address. Then opens `Library_Card.txt` and updates it again. | User updates address in the Student Portal once. |
| **Processing** | The application must parse the text file format specifically. | The DBMS handles the query `UPDATE Students SET Address = ...`. |
| **Manipulation** | If the files are locked by another user, the update fails or overwrites blindly. | DBMS handles concurrency; queues the update or locks the row safely. |
| **Storage** | Data stored in disparate files; high risk of mismatch. | Data stored centrally; change propagates everywhere instantly. |

### Pros and Cons
**FMS:**
*   *Pros:* Simple to set up for tiny tasks, no expensive software required.
*   *Cons:* Data Redundancy (duplicates), Inconsistency, Security is hard to enforce.

**DBMS:**
*   *Pros:* Centralized control, Data Independence, Efficient access, Integrity/Security.
*   *Cons:* Expensive, Complex, High hardware overhead.

## Gemini: Parameter Comparison

| Parameter | FMS | DBMS |
| :--- | :--- | :--- |
| **Redundancy & Consistency** | **High Redundancy:** Same data in multiple files. **Low Consistency:** Updating one file doesn't update others. | **Low Redundancy:** Data stored once. **High Consistency:** Changes reflect everywhere. |
| **Access** | **Rigid:** Applications are written for specific file formats. New queries require new programs. | **Flexible:** SQL allows querying data in new ways without rewriting code. |
| **Data Isolation** | **High:** Data is scattered in various formats/files. Hard to aggregate. | **Low:** Data is centralized and standardized. |
| **Integrity Problems** | **High:** Hard to enforce rules like "Grade cannot be > 4.0" across text files. | **Low:** Constraints (Checks, Foreign Keys) enforce rules automatically. |
| **Atomicity** | **No:** If a script crashes halfway through writing a file, data is corrupted. | **Yes:** Transactions are "All or Nothing". |

---

## DBMS Personnel
## Gemini: Roles & Duties

1.  **Database Administrator (DBA):**
    *   *Duty:* The "Superuser". Responsible for authorizing access, monitoring performance, backing up data, and acquiring hardware/software resources.
    *   *Example:* The IT Head who decides "We need to upgrade to a faster server because queries are slow."

2.  **Database Designers:**
    *   *Duty:* They define the content, the structure, the constraints, and functions or transactions against the database. They talk to users to understand what data needs to be stored.
    *   *Example:* The architect who decides "We need a 'Student' table and a 'Course' table, and they should be linked."

3.  **End Users:**
    *   *Duty:* The people who use the data.
        *   *Naive Users:* Use standard forms (e.g., Bank tellers).
        *   *Sophisticated Users:* Engineers/Analysts who write SQL queries.

4.  **System Analysts & Application Programmers:**
    *   *Duty:* Analysts determine requirements; Programmers write the code (Java, Python) that talks to the DBMS.
